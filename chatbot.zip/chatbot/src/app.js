'use strict';

const { App } = require('jovo-framework');
const { NlpjsNlu } = require('jovo-nlu-nlpjs');
const { JovoDebugger } = require('jovo-plugin-debugger');
const { FileDb } = require('jovo-db-filedb');
const { Alexa } = require('jovo-platform-alexa')
const { getProducts } = require('./api')
const { WebPlatform } = require('jovo-platform-web');

// ------------------------------------------------------------------
// APP INITIALIZATION
// ------------------------------------------------------------------

const app = new App();

const webPlatform = new WebPlatform();
webPlatform.use(new NlpjsNlu());

app.use(webPlatform);

// ------------------------------------------------------------------
// APP LOGIC
// ------------------------------------------------------------------

app.setHandler({
  LAUNCH() {
    this.ask(
      `Hello, I am here to assist you in understanding our product features in depth, ` +
      `as well as informing you the list of products currently available. ` +
      `What would you like to do?`
    ).followUpState('ProductsOrProduct')
    this.$webApp.showQuickReplies([
      'Yes',
      'No'
    ])
  },

  Unhandled() {
    this.tell("Sorry, I didn't catch that. Can you say that again?")
  },

  ProductOrProducts: {
    ProductsIntent() {
      let names = []
      getProducts().then(res => {
        res.data.map(product => {
          names.push(product.name)
        })
      }).catch(error => {
        console.log(error)
      })
      names.forEach(name => {
        this.tell(name)
      })
    },

    Unhandled() {
      this.tell("Sorry, I didn't catch that. Can you say that again?")
    }
  },

  HelloWorldIntent() {
    return this.toIntent('LAUNCH')
  },

  MyNameIsIntent() {
    this.tell('Hey ' + this.$inputs.name.value + ', nice to meet you!');
  },
});

module.exports = { app };
